---
title: "MDFriday"
---

# 主页说明

The `_index.md` file is used to define the content for the homepage of the site.  
It provides a way to specify title, and any other content that should appear on the front page.  
This file is necessary to generate the `index.html` page in the site's public directory.  
MDFriday uses this file to render the homepage with the correct layout and content.

This file helps MDFriday understand how to construct the homepage, and without it, MDFriday would not know what content to display on the site’s front page.

---
