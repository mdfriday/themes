---
date: 2023-01-12
title: Featured Album
featured: true
private: true
description: This is a featured album. It is private, so it is only shown on the homepage.
---

##### cover

manny-becerra-iflbnnolhuo-unsplash.jpg
