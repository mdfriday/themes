---
description: A private gallery that is only available by direct link.
title: Private
private: true
params:
  private: true # This gallery does not show in lists, RSS, sitemaps, etc. On list pages, use cascade to hide descendants.
---
