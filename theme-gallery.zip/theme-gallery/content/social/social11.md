+++
title = "linkedin"
url = "https://mdfriday.com"
weight = 11
+++

Description
