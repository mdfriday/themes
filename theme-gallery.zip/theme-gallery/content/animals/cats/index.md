---
date: 2023-04-01
title: Cats
sort_by: Name
categories: ["animals", "nature"]
---

##### cover

manja-vitolic-gKXKBY-C-Dk-unsplash.jpg

##### alexander-london-mJaD10XeD7w-unsplash.jpg

Brown tabby cat on white stairs by Alexander London

##### amber-kipp-75715CVEJhI-unsplash.jpg

Selective focus photography of orange and white cat on brown table by Amber Kipp

##### manja-vitolic-gKXKBY-C-Dk-unsplash.jpg

Gipsy the Cat was sitting on a bookshelf one afternoon and just stared right at me, kinda saying: “Will you take a picture already?”

##### michael-sum-LEpfefQf4rU-unsplash.jpg

This is the cutest and loveliest cat I have ever met in my life. He is BU BU, a cat with 6 fingers, which is unusual, but in fact, smarter than any cat. He meows every time he sees me, and jumps to my bed and sits with me.
