##### main

- [Home](/)
- [Animals](/animals/)
- [Fashion & Beauty](/fashion-beauty.html)
- [Nature](/nature.html)
- [About](/about.html)

##### footer

- [Author](https://mdfriday.com)
